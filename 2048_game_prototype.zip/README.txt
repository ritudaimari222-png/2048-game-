# 2048 Game Prototype

Open `index.html` in a modern browser.

Controls:
- Desktop: Arrow keys
- Mobile: Swipe

Features:
- 4x4 board
- Score and persistent best score
- Random 2/4 tiles
- Tile merging
- 2048 win detection
- Game-over detection
- New Game / Play Again
- Mobile-friendly layout
